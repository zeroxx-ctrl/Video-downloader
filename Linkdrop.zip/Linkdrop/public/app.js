const $=selector=>document.querySelector(selector);
const $$=selector=>[...document.querySelectorAll(selector)];
const icon=(name,cls='')=>{const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('aria-hidden','true');if(cls)svg.setAttribute('class',cls);const use=document.createElementNS('http://www.w3.org/2000/svg','use');use.setAttribute('href',`#i-${name}`);svg.append(use);return svg;};
const el=(tag,cls,text)=>{const node=document.createElement(tag);if(cls)node.className=cls;if(text!==undefined)node.textContent=text;return node;};
let prefs={video:'1080',audio:320,autoSave:true};
try{prefs={...prefs,...JSON.parse(localStorage.getItem('linkdrop-prefs')||'{}')};}catch{}
let media=null,kind='video',quality=Number(prefs.video)||'best',busy=false,ready=false,jobs=[],polling=false,lastJobRender='';
const autoSaved=new Set();let firstPoll=true;
const sizes=bytes=>!bytes?'':bytes>1024*1024*1024?`${(bytes/1024/1024/1024).toFixed(1)} GB`:`${(bytes/1024/1024).toFixed(1)} MB`;
const duration=seconds=>{if(!seconds)return '';const mins=Math.floor(seconds/60);return `${mins}:${String(Math.floor(seconds%60)).padStart(2,'0')}`;};
function toast(text){$('#toast').textContent=text;$('#toast').hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('#toast').hidden=true,4500);}
function notice(text,type=''){const target=$('#notice');target.textContent=text;target.className=type;target.hidden=!text;}
async function api(route,{method='GET',data}={}){
  const response=await fetch(route,{method,credentials:'same-origin',headers:data||method!=='GET'?{'Content-Type':'application/json'}:{},body:data?JSON.stringify(data):undefined,signal:AbortSignal.timeout(100000)});
  const result=await response.json();if(!response.ok)throw new Error(result.error||'Could not complete this request.');return result;
}
function setView(view){for(const name of ['download','history','settings'])$(`#${name}-view`).hidden=name!==view;$$('.nav-item[data-view]').forEach(button=>{button.classList.toggle('active',button.dataset.view===view);if(button.dataset.view===view)button.setAttribute('aria-current','page');else button.removeAttribute('aria-current');});$('#breadcrumb strong').textContent=({download:'Downloader',history:'My downloads',settings:'Preferences'})[view];window.scrollTo({top:0,behavior:'smooth'});}
$$('[data-view]').forEach(button=>button.addEventListener('click',()=>setView(button.dataset.view)));
const qualityNames={2160:'4K Ultra HD',1440:'Quad HD',1080:'Full HD',720:'HD quality',480:'Standard',360:'Smaller file',240:'Low data',144:'Smallest file'};
function renderQualities(){
  const group=$('#quality-options');group.replaceChildren();
  const list=kind==='audio'?[320,256,192]:media?(media.hasVideo?['best',...media.qualities]:[]):['best',1080,720,480];
  if(!list.includes(quality))quality=kind==='audio'?320:list.includes(Number(prefs.video))?Number(prefs.video):'best';
  list.forEach(value=>{
    const button=el('button','quality-option'+(quality===value?' selected':''));button.type='button';button.setAttribute('role','radio');button.setAttribute('aria-checked',String(quality===value));button.tabIndex=quality===value?0:-1;
    const title=kind==='audio'?`${value} kbps`:value==='best'?'Best':`${value}p`;
    const sub=kind==='audio'?({320:'Highest bitrate',256:'Great balance',192:'Smaller file'})[value]:value==='best'?'Original quality':qualityNames[value]||'Source quality';
    button.append(el('strong','',title),el('small','',sub));
    button.addEventListener('click',()=>{quality=value;renderQualities();updateDownloadButton();});
    button.addEventListener('keydown',event=>{if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)){event.preventDefault();const direction=['ArrowRight','ArrowDown'].includes(event.key)?1:-1;quality=list[(list.indexOf(value)+direction+list.length)%list.length];renderQualities();group.querySelector('[aria-checked="true"]').focus();updateDownloadButton();}});
    group.append(button);
  });
  $('#quality-label').textContent=kind==='audio'?'AUDIO QUALITY':'VIDEO QUALITY';
  $('#availability-label').textContent=kind==='audio'?'MP3 output bitrate':media?'Available in this source':'Available qualities appear after checking your link';
  const note=kind==='audio'?'320 kbps MP3 uses the best available audio. Source quality still matters.':'Original quality, always. We never upscale your video.';
  $('#quality-note').replaceChildren(icon('info'),document.createTextNode(note));
}
function updateDownloadButton(){
  $('#download-button').disabled=!media||busy||!ready||(kind==='audio'&&!media.hasAudio)||(kind==='video'&&!media.hasVideo);
  $('#download-button>span').textContent=kind==='audio'?'Download audio':'Download video';$('#download-button .button-format').textContent=kind==='audio'?'MP3':'MP4';
}
function changeKind(value){kind=value;quality=kind==='audio'?Number(prefs.audio):prefs.video==='best'?'best':Number(prefs.video);$$('[data-kind]').forEach(button=>{const selected=button.dataset.kind===kind;button.classList.toggle('selected',selected);button.setAttribute('aria-selected',String(selected));button.tabIndex=selected?0:-1;});renderQualities();updateDownloadButton();if(media&&kind==='audio'&&!media.hasAudio)notice('This video has no audio track. You can still save the video.');else if(media)notice('');}
$$('[data-kind]').forEach(button=>{button.addEventListener('click',()=>changeKind(button.dataset.kind));button.addEventListener('keydown',event=>{if(['ArrowLeft','ArrowRight'].includes(event.key)){event.preventDefault();changeKind(kind==='audio'?'video':'audio');$('[data-kind="'+kind+'"]').focus();}});});
$('#video-url').addEventListener('input',()=>{if(media){media=null;$('#media-preview').hidden=true;renderQualities();updateDownloadButton();}if(!busy)notice('');});
$('#paste-button').addEventListener('click',async()=>{try{$('#video-url').value=await navigator.clipboard.readText();$('#video-url').dispatchEvent(new Event('input'));$('#video-url').focus();}catch{toast('Click the link field and press Ctrl+V to paste.');$('#video-url').focus();}});
$('#link-form').addEventListener('submit',async event=>{
  event.preventDefault();if(busy)return;busy=true;media=null;const requestedUrl=$('#video-url').value;$('#media-preview').hidden=true;$('#inspect-button').disabled=true;$('#inspect-button').classList.add('busy');$('#inspect-button>span').textContent='Checking…';notice('Finding your video and its available qualities…','loading');updateDownloadButton();
  try{
    const result=await api('/api/inspect',{method:'POST',data:{url:requestedUrl}});
    if($('#video-url').value!==requestedUrl){notice('Your link changed. Click Find video to check the new link.');return;}
    media=result;$('#media-title').textContent=media.title;$('#media-platform').textContent=media.platform;$('#media-details').textContent=[media.author,duration(media.duration)].filter(Boolean).join(' · ');
    const thumbnail=$('#media-thumb');thumbnail.hidden=!media.thumbnail;if(media.thumbnail)thumbnail.src=media.thumbnail;else thumbnail.removeAttribute('src');thumbnail.onerror=()=>thumbnail.hidden=true;
    $('#media-preview').hidden=false;notice('');renderQualities();
    if(kind==='audio'&&!media.hasAudio)notice('This video has no audio track. Choose Video to save it.');
  }catch(error){notice(error.name==='TimeoutError'?'The platform took too long. Please try again.':error.message,'error');}
  finally{busy=false;$('#inspect-button').disabled=false;$('#inspect-button').classList.remove('busy');$('#inspect-button>span').textContent='Find video';updateDownloadButton();}
});
$('#download-button').addEventListener('click',async()=>{
  if(!media||busy)return;busy=true;updateDownloadButton();
  try{await api('/api/jobs',{method:'POST',data:{mediaId:media.id,kind,quality}});notice('Your download has started. Follow its progress below.');await poll();$('.recent-section').scrollIntoView({behavior:'smooth',block:'nearest'});}
  catch(error){notice(error.message,'error');}finally{busy=false;updateDownloadButton();}
});
function save(job){const anchor=el('a');anchor.href=`/api/jobs/${job.id}/file`;anchor.download='';document.body.append(anchor);anchor.click();anchor.remove();}
function jobElement(job){
  const row=el('article','job');row.dataset.jobId=job.id;const badge=el('span','job-icon');badge.append(icon(job.kind==='audio'?'music':'video'));const main=el('div','job-main');main.append(el('h3','',job.title));
  let status=job.state==='complete'?`Ready · ${sizes(job.size)}`:job.state==='converting'?'Finishing your file…':job.state==='cancelled'?'Cancelled':job.state==='error'?'Could not download':job.progress===null?'Downloading…':`Downloading · ${job.progress}%`;
  if(job.state==='downloading'&&job.speed)status+=` · ${sizes(job.speed)}/s`;
  main.append(el('p','',`${job.label} · ${status}`));
  if(job.error)main.append(el('p','job-error',job.error));
  if(['downloading','converting'].includes(job.state)){const track=el('div','progress-track'+(job.state==='converting'||job.progress===null?' indeterminate':''));track.setAttribute('role','progressbar');track.setAttribute('aria-label',status);if(job.progress!==null)track.setAttribute('aria-valuenow',String(job.progress));const fill=el('div','progress-fill');fill.style.width=`${job.progress||0}%`;track.append(fill);main.append(track);}
  const actions=el('div','job-actions');
  if(job.state==='complete'){const link=el('a');link.href=`/api/jobs/${job.id}/file`;link.download='';link.title='Save file';link.setAttribute('aria-label',`Save ${job.title}`);link.append(icon('download'),el('span','save-label','Save'));actions.append(link);}
  if(['downloading','converting'].includes(job.state)){const cancel=el('button','','Cancel');cancel.addEventListener('click',async()=>{cancel.disabled=true;try{await api(`/api/jobs/${job.id}/cancel`,{method:'POST',data:{}});await poll();}catch(e){toast(e.message);cancel.disabled=false;}});actions.append(cancel);}
  else{const remove=el('button','delete');remove.title='Remove temporary file';remove.setAttribute('aria-label',`Remove ${job.title}`);remove.append(icon('trash'));remove.addEventListener('click',async()=>{remove.disabled=true;try{await api(`/api/jobs/${job.id}`,{method:'DELETE'});await poll();}catch(e){toast(e.message);remove.disabled=false;}});actions.append(remove);}
  row.append(badge,main,actions);return row;
}
function renderJobs(){
  for(const [target,list]of[[$('#recent-list'),jobs.slice(0,3)],[$('#history-list'),jobs]]){target.replaceChildren();if(!list.length){const empty=el('div','empty-state');const message=el('div');message.append(el('strong','','A clean slate. Your next great download goes here.'),el('p','','Paste a link above to get started.'));empty.append(icon('download'),message);target.append(empty);}else for(const job of list)target.append(jobElement(job));}
  $('#history-count').textContent=jobs.length;$('#recent-total').textContent=jobs.length;$('#clear-history').disabled=!jobs.some(job=>!['downloading','converting'].includes(job.state));
}
async function poll(){if(polling)return;polling=true;try{
  const result=await api('/api/jobs');jobs=result.jobs;const fingerprint=JSON.stringify(jobs);if(fingerprint!==lastJobRender){lastJobRender=fingerprint;renderJobs();}
  for(const job of jobs){if(job.state==='complete'&&!autoSaved.has(job.id)){autoSaved.add(job.id);if(!firstPoll&&prefs.autoSave){save(job);toast('Your file is ready. If it did not save, use the Save button.');}}}firstPoll=false;
}catch{}finally{polling=false;}}
$('#clear-history').addEventListener('click',async()=>{const button=$('#clear-history');button.disabled=true;try{for(const job of jobs.filter(j=>!['downloading','converting'].includes(j.state)))await api(`/api/jobs/${job.id}`,{method:'DELETE'});await poll();toast('Finished downloads cleared. Your saved browser copies are unchanged.');}catch(e){toast(e.message);}finally{button.disabled=false;}});
function savePrefs(){prefs={video:$('#default-video').value,audio:Number($('#default-audio').value),autoSave:$('#auto-save').checked};try{localStorage.setItem('linkdrop-prefs',JSON.stringify(prefs));$('#preference-status').textContent='Preferences saved in this browser.';}catch{$('#preference-status').textContent='Browser storage is unavailable. Preferences will last until this page closes.';}quality=kind==='audio'?prefs.audio:prefs.video==='best'?'best':Number(prefs.video);renderQualities();updateDownloadButton();}
$('#default-video').value=String(prefs.video);$('#default-audio').value=String(prefs.audio);$('#auto-save').checked=prefs.autoSave;$$('.settings-card input,.settings-card select').forEach(input=>input.addEventListener('change',savePrefs));
async function health(){
  $('#refresh-engine').disabled=true;
  try{const status=await api('/api/health');ready=status.ready;$('#engine-details').textContent=ready?`Ready · yt-dlp ${status.downloader} · FFmpeg installed`:'Tools are missing. Run Start-Linkdrop.cmd or follow README setup.';$('#retention-note').textContent=`Temporary files are removed after ${status.retentionMinutes} minutes or when the app restarts. Maximum file size: ${status.maxFileMB} MB. Browser-saved copies are yours to keep.`;if(status.mode==='web'){$('#workspace-label').textContent='Web workspace';$('#privacy-copy').replaceChildren(document.createTextNode('No tracking. No ad networks.'),document.createElement('br'),document.createTextNode('Files are processed on this server.'));}if(!ready)notice('Download tools are not ready. Open Preferences for setup details.','error');}
  catch{ready=false;$('#engine-details').textContent='Cannot reach the download engine. Start Linkdrop and reload this page.';notice('The download engine is offline. Start Linkdrop and reload this page.','error');}
  finally{$('#refresh-engine').disabled=false;updateDownloadButton();}
}
$('#refresh-engine').addEventListener('click',()=>health());
$('#about-button').addEventListener('click',()=>$('#about-dialog').showModal());$$('.close-dialog,.close-about').forEach(button=>button.addEventListener('click',()=>$('#about-dialog').close()));$('#about-dialog').addEventListener('click',event=>{if(event.target===$('#about-dialog')){const box=event.target.getBoundingClientRect();if(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom)event.target.close();}});
renderQualities();renderJobs();health();poll();setInterval(poll,1500);
