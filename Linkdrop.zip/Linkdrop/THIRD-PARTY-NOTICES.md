# Third-party components

The MIT license covers Linkdrop's application source, not bundled dependencies.

- yt-dlp: https://github.com/yt-dlp/yt-dlp. Main source is Unlicense; Windows standalone builds include components with other licenses and are distributed under GPLv3+. Read https://github.com/yt-dlp/yt-dlp#license and the release's license information before redistributing the binaries. Source releases are at https://github.com/yt-dlp/yt-dlp/releases.
- FFmpeg: https://ffmpeg.org/. Windows essentials builds are supplied by https://www.gyan.dev/ffmpeg/builds/ and are GPLv3. The build's license is copied to runtime/FFmpeg-LICENSE.txt. Build configuration and matching source links are available on the build supplier's page. These are unmodified binaries.
- Node.js: https://nodejs.org/. Node is MIT-licensed and includes third-party notices; its license is copied to runtime/Node-LICENSE.txt when bundled. Matching source is at https://nodejs.org/dist/ for the included version.

The source ZIP excludes third-party binaries and retrieves them from their publishers on first run. Keep applicable licenses and corresponding source obligations when distributing a bundle.
