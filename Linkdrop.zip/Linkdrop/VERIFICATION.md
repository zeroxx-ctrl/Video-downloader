# Verification — 2 November 2026

## Automated checks

`node --test test/*.test.mjs`: **12 passed, 0 failed**.

Coverage includes supported URL canonicalization, hostile URL rejection, source resolutions, portrait video, silent media, missing Instagram codec/dimension metadata, invalid MP3 bitrates, playlist/live rejection, real local HTTP API and subprocess/file lifecycle, cross-origin rejection, session/file isolation, cancellation, deletion, simultaneous download slots, cancellation during final verification, and shared pending dependency checks.

JavaScript syntax checks passed. Windows PowerShell launcher parsed successfully and started the actual server as a hidden background process. Dependency installation succeeded after checksum verification of the downloaded yt-dlp and FFmpeg files.

## Real platform download tests

These requests used the application's actual HTTP endpoints, yt-dlp 2026.10.26, FFmpeg 9.0.2 and Node 24.19.0. Saved files were inspected with ffprobe, not inferred from their names.

| Source | Requested | Verified output |
| --- | --- | --- |
| Blender's Big Buck Bunny on YouTube (`YE7VzlLtp-4`) | 1080p MP4 | 1920×1080 AV1 video + AAC audio, 596.544 seconds, 101,267,553 bytes |
| Same YouTube video | 720p MP4 | 1280×720 H.264 video + AAC audio, 596.544 seconds, 104,130,577 bytes |
| Same YouTube video | 320 kbps MP3 | MP3 stream at **320,000 bits/second**, 596.544 seconds, 23,863,823 bytes |
| Instagram-owned test Reel (`Chunk8-jurw`) | 720p MP4 | 720×1280 H.264 portrait video, 4.967 seconds, 1,949,801 bytes |

The Instagram test Reel has no audio track; the app correctly disabled MP3 for it. Instagram download was also started through the browser interface and reached Ready with a Save link. The old YouTube test video `BaW_jenozKc` returned unavailable; the interface displayed a clear error.

## Browser checks

- Link inspection, real quality choices, video/MP3 switching and disabled unavailable audio.
- Download start, completed item and Save action availability.
- Preferences navigation and saved checkbox state.
- Desktop viewport at 1280 pixels and mobile viewport at 390 pixels; no horizontal overflow.
- No browser console warnings/errors during the checked flow.

## Verification limits

- The Docker configuration is supplied but its image build was **not run** because Docker is not installed on this computer.
- Windows startup was tested on this computer with Node already installed. The automatic Node first-run bootstrap for a fresh PC is provided but was not run on a second machine.
- Live success on these samples is not a guarantee for every platform link. Restrictions, source quality and extraction behavior can change.
- MP4 is a container: the verified 1080p source uses AV1, which requires an AV1-capable player. The app prefers H.264 where it is offered at the requested resolution.
- Test media files are kept outside the deliverable and are excluded from the ZIP.
