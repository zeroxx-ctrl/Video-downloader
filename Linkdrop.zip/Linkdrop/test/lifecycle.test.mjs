import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp, rm} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {Engine} from '../lib/engine.mjs';
import {createApp} from '../server.mjs';

const info={formats:[{format_id:'22',width:1280,height:720,vcodec:'h264',acodec:'aac',ext:'mp4'}]};
function addMedia(engine) {
  engine.media.set('test',{owner:'review',created:Date.now(),summary:{title:'Test',platform:'YouTube'},url:'https://www.youtube.com/watch?v=BaW_jenozKc',info});
}
const selection={mediaId:'test',kind:'video',quality:720};

test('simultaneous starts reserve only two running download slots',async t=>{
  const dir=await mkdtemp(path.join(os.tmpdir(),'linkdrop-concurrency-test-'));
  const engine=new Engine({dataDir:dir});
  let release;
  const running=new Promise(resolve=>{release=resolve;});
  engine.run=async job=>{await running;job.state='complete';};
  t.after(async()=>{release();await engine.close();await rm(dir,{recursive:true,force:true});});
  await engine.ready;addMedia(engine);
  const results=await Promise.allSettled(Array.from({length:20},()=>engine.start('review',selection)));
  assert.equal(results.filter(result=>result.status==='fulfilled').length,2);
  assert.ok(results.filter(result=>result.status==='rejected').every(result=>result.reason.status===429));
});

test('late cancellation remains cancelled after output verification',async t=>{
  const dir=await mkdtemp(path.join(os.tmpdir(),'linkdrop-cancel-test-'));
  // A real subprocess writes its final output and exits, as yt-dlp does.
  const script=`const a=process.argv;const p=a[a.indexOf('-o')+1].replace('%(ext)s','mp4');require('node:fs').writeFileSync(p,'video');console.log('__FILE__'+JSON.stringify(p));`;
  const engine=new Engine({dataDir:dir,command:process.execPath,prefix:['-e',script,'--']});
  t.after(async()=>{await engine.close();await rm(dir,{recursive:true,force:true});});
  await engine.ready;addMedia(engine);
  const started=await engine.start('review',selection);
  const job=engine.jobs.get(started.id);
  let cancelState;
  // run() first resumes after close, then awaits stat. This microtask cancels
  // during that final asynchronous check, matching a cancellation API request.
  job.child.on('close',()=>queueMicrotask(()=>{cancelState=engine.cancel('review',job.id).state;}));
  await job.running;
  assert.equal(cancelState,'cancelled');
  assert.equal(job.state,'cancelled');
});

test('simultaneous health requests share the pending dependency check',async t=>{
  const dir=await mkdtemp(path.join(os.tmpdir(),'linkdrop-health-test-'));
  const app=createApp({dataDir:dir});
  t.after(async()=>{await app.close();await rm(dir,{recursive:true,force:true});});
  await app.engine.ready;
  // Exercise the actual HTTP request handler without requiring a network bind.
  app.server.address=()=>({port:47821});
  let calls=0,release;
  const pending=new Promise(resolve=>{release=resolve;});
  app.engine.health=async()=>{calls++;await pending;return {ready:true};};
  const responses=Array.from({length:20},()=>new Promise(resolve=>{
    const req={headers:{host:'127.0.0.1:47821'},method:'GET',url:'/api/health'};
    app.server.emit('request',req,{setHeader(){},writeHead(){},end(){resolve();}});
  }));
  release();await Promise.all(responses);
  assert.equal(calls,1);
});
