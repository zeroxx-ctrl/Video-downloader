import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createApp } from '../server.mjs';

test('API validates origins, isolates downloads and serves completed files', async t => {
  const dir=await mkdtemp(path.join(os.tmpdir(),'linkdrop-test-'));
  const fixture=path.join(dir,'extractor.mjs');
  // External extractor fixture; HTTP, sessions, job manager, subprocesses and disk are real.
  await writeFile(fixture,`import {writeFileSync} from 'node:fs';
  const args=process.argv.slice(2);
  if(args.includes('--version')) { console.log('test'); }
  else if(args.includes('--dump-single-json')) {
    console.log(JSON.stringify({id:'test',title:'Test video',duration:2,formats:[{format_id:'22',width:1280,height:720,vcodec:'h264',acodec:'aac',ext:'mp4'}]}));
  } else {
    const output=args[args.indexOf('-o')+1].replace('%(ext)s','mp4');
    console.log('__PROGRESS__'+JSON.stringify({status:'downloading',downloaded_bytes:4,total_bytes:4}));
    setTimeout(()=>{writeFileSync(output,'test video');console.log('__FILE__'+JSON.stringify(output));},150);
  }`);
  const app=createApp({dataDir:path.join(dir,'data'),command:process.execPath,prefix:[fixture],ffmpeg:process.execPath});
  await new Promise(r=>app.server.listen(0,'127.0.0.1',r));
  t.after(async()=>{await app.close();await rm(dir,{recursive:true,force:true});});
  const base=`http://127.0.0.1:${app.server.address().port}`;
  const home=await fetch(`${base}/api/health`);
  const cookie=home.headers.get('set-cookie').split(';')[0];
  const headers={'Content-Type':'application/json',Origin:base,Cookie:cookie};
  async function post(route,body,custom={}) {return fetch(base+route,{method:'POST',headers:{...headers,...custom},body:JSON.stringify(body)});}
  assert.equal((await post('/api/inspect',{url:'https://youtube.com/watch?v=BaW_jenozKc'},{Origin:'https://evil.example'})).status,403);
  assert.equal((await post('/api/inspect',{url:'http://localhost/'})).status,400);
  const response=await post('/api/inspect',{url:'https://youtu.be/BaW_jenozKc'});
  assert.equal(response.status,200);
  const media=await response.json();
  assert.deepEqual(media.qualities,[720]);
  assert.equal((await post('/api/jobs',{mediaId:media.id,kind:'video',quality:1080})).status,400);
  const started=await post('/api/jobs',{mediaId:media.id,kind:'video',quality:720});
  assert.equal(started.status,202);
  const job=await started.json();
  let finished;
  for(let i=0;i<80;i++) {finished=await (await fetch(base+'/api/jobs',{headers:{Cookie:cookie}})).json();if(finished.jobs[0].state==='complete')break;await new Promise(r=>setTimeout(r,25));}
  assert.equal(finished.jobs[0].state,'complete');
  const file=await fetch(`${base}/api/jobs/${job.id}/file`,{headers:{Cookie:cookie}});
  assert.equal(file.status,200);
  assert.equal(await file.text(),'test video');
  assert.match(file.headers.get('content-disposition'),/attachment/);
  assert.equal((await fetch(`${base}/api/jobs/${job.id}/file`)).status,404);
  assert.deepEqual((await (await fetch(`${base}/api/jobs`)).json()).jobs,[]);
  assert.equal((await fetch(`${base}/api/jobs/${job.id}`,{method:'DELETE',headers})).status,200);
  assert.equal((await fetch(`${base}/api/jobs/${job.id}/file`,{headers:{Cookie:cookie}})).status,404);
  const next=await (await post('/api/jobs',{mediaId:media.id,kind:'video',quality:720})).json();
  assert.equal((await post(`/api/jobs/${next.id}/cancel`,{})).status,200);
  const cancelled=(await (await fetch(base+'/api/jobs',{headers:{Cookie:cookie}})).json()).jobs[0];
  assert.equal(cancelled.state,'cancelled');
});
