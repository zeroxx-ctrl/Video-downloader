import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeUrl, summarize, selectFormat } from '../lib/media.mjs';

test('normalizes video links without tracking or playlist parameters', () => {
  assert.equal(normalizeUrl(' https://youtu.be/BaW_jenozKc?si=tracking '), 'https://www.youtube.com/watch?v=BaW_jenozKc');
  assert.equal(normalizeUrl('https://m.youtube.com/shorts/BaW_jenozKc?list=abc'), 'https://www.youtube.com/watch?v=BaW_jenozKc');
  assert.equal(normalizeUrl('https://www.instagram.com/reel/ABC_123-/?igsh=secret'), 'https://www.instagram.com/reel/ABC_123-/');
});
test('rejects unsupported endpoints and URL tricks', () => {
  for (const url of ['http://127.0.0.1/x','file:///etc/passwd','https://youtube.com.evil.com/watch?v=BaW_jenozKc','https://user:pass@youtube.com/watch?v=BaW_jenozKc','https://youtube.com:8080/watch?v=BaW_jenozKc','https://youtube.com/playlist?list=123','https://instagram.com/someone/','--exec=bad','https://youtube.com/redirect?q=http://localhost','https://youtube.com/watch?v=bad']) {
    assert.throws(() => normalizeUrl(url), /link|URL|video/i, url);
  }
});
const info = {id:'example', title:'A test video', duration:10, extractor_key:'Youtube', formats:[
  {format_id:'137',width:1920,height:1080,vcodec:'avc1',acodec:'none',ext:'mp4',tbr:2500},
  {format_id:'22',width:1280,height:720,vcodec:'avc1',acodec:'mp4a',ext:'mp4',tbr:1000},
  {format_id:'18',width:640,height:360,vcodec:'avc1',acodec:'mp4a',ext:'mp4',tbr:400},
  {format_id:'140',vcodec:'none',acodec:'mp4a',ext:'m4a',abr:128}
]};
test('offers only source qualities and selects video with audio', () => {
  assert.deepEqual(summarize(info).qualities, [1080,720,360]);
  assert.equal(selectFormat(info,{kind:'video',quality:720}).format,'22');
  assert.equal(selectFormat(info,{kind:'video',quality:1080}).format,'137+bestaudio[ext=m4a]/137+bestaudio');
  assert.throws(()=>selectFormat(info,{kind:'video',quality:480}),/available/);
});
test('portrait video uses the shorter dimension as quality', () => {
  const portrait={...info,formats:[{format_id:'ig',width:1080,height:1920,vcodec:'h264',acodec:'aac',ext:'mp4'}]};
  assert.deepEqual(summarize(portrait).qualities,[1080]);
  assert.equal(selectFormat(portrait,{kind:'video',quality:1080}).format,'ig');
});
test('MP3 requires audio and supported bitrate', () => {
  assert.equal(selectFormat(info,{kind:'audio',quality:320}).audioQuality,'320K');
  assert.throws(()=>selectFormat(info,{kind:'audio',quality:999}),/quality/);
  const silent={...info,formats:[info.formats[0]]};
  assert.equal(summarize(silent).hasAudio,false);
  assert.throws(()=>selectFormat(silent,{kind:'audio',quality:320}),/audio/);
  assert.equal(selectFormat(silent,{kind:'video',quality:1080}).format,'137');
});
test('rejects playlists and live streams', () => {
  assert.throws(()=>summarize({...info,_type:'playlist',entries:[]}),/single|one/i);
  assert.throws(()=>summarize({...info,is_live:true}),/live/i);
});
test('Instagram direct MP4 formats can omit codec metadata', () => {
  const reel={id:'reel',extractor_key:'Instagram',formats:[{format_id:'0',width:720,height:1280,ext:'mp4',url:'https://cdn.example/video.mp4'}]};
  assert.deepEqual(summarize(reel).qualities,[720]);
  assert.equal(summarize(reel).hasAudio,true);
  assert.equal(selectFormat(reel,{kind:'video',quality:720}).format,'0');
  assert.equal(selectFormat(reel,{kind:'audio',quality:320}).audioQuality,'320K');
});
test('video with unknown dimensions offers original without fabricated resolutions',()=>{
  const reel={formats:[{format_id:'0',ext:'mp4',acodec:'none'}]};
  const summary=summarize(reel);
  assert.deepEqual(summary.qualities,[]);
  assert.equal(summary.hasVideo,true);
  assert.equal(selectFormat(reel,{kind:'video',quality:'best'}).label,'MP4 · Original');
  assert.throws(()=>selectFormat(reel,{kind:'video',quality:1080}),/available/);
});
