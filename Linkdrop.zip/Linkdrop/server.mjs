import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { Engine } from './lib/engine.mjs';
import { AppError } from './lib/media.mjs';

const root=path.dirname(fileURLToPath(import.meta.url));
const assets=new Map([['/',['index.html','text/html; charset=utf-8']],['/app.js',['app.js','text/javascript; charset=utf-8']],['/style.css',['style.css','text/css; charset=utf-8']],['/icon.svg',['icon.svg','image/svg+xml']]]);
const json=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data));};
async function body(req) {
  if(!req.headers['content-type']?.startsWith('application/json'))throw new AppError('Send a JSON request.',415);
  let text='';for await(const chunk of req){text+=chunk;if(Buffer.byteLength(text)>8192)throw new AppError('Request is too large.',413);}
  try {const result=JSON.parse(text);if(!result||typeof result!=='object'||Array.isArray(result))throw Error();return result;}catch{throw new AppError('Invalid request data.');}
}
export function createApp(options={}) {
  const engine=new Engine(options);
  const publicOrigin=options.publicOrigin || process.env.PUBLIC_ORIGIN || '';
  if(publicOrigin && !/^https?:\/\/[^/]+$/.test(publicOrigin))throw new Error('PUBLIC_ORIGIN must be an origin such as https://downloads.example.com (no trailing slash).');
  const sessions=new Map();
  let healthCache=null;
  const sessionTimer=setInterval(()=>{for(const [id,time] of sessions)if(Date.now()-time>86400000)sessions.delete(id);},60000);sessionTimer.unref();
  const server=http.createServer(async(req,res)=>{
    res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');
    res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' https: data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
    try {
      const port=server.address()?.port;
      const origins=publicOrigin?[publicOrigin]:[`http://127.0.0.1:${port}`,`http://localhost:${port}`];
      const allowedHosts=origins.map(origin=>new URL(origin).host);
      if(!allowedHosts.includes(req.headers.host))throw new AppError('Host not allowed.',403);
      if(req.headers.origin && !origins.includes(req.headers.origin))throw new AppError('This request must come from the app.',403);
      if(req.headers['sec-fetch-site']==='cross-site')throw new AppError('Cross-site requests are not allowed.',403);
      if(['POST','DELETE'].includes(req.method) && !origins.includes(req.headers.origin))throw new AppError('A same-origin request is required.',403);
      const url=new URL(req.url,origins[0]);
      const cookie=/(?:^|;\s*)linkdrop_session=([a-f0-9]{64})(?:;|$)/.exec(req.headers.cookie || '')?.[1];
      let owner=cookie;
      if(!owner || !sessions.has(owner)) {
        if(sessions.size>=1000)throw new AppError('Server is busy. Please try again later.',503);
        owner=randomBytes(32).toString('hex');sessions.set(owner,Date.now());
        res.setHeader('Set-Cookie',`linkdrop_session=${owner}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400${publicOrigin.startsWith('https:')?'; Secure':''}`);
      } else sessions.set(owner,Date.now());
      if(req.method==='GET'&&url.pathname==='/api/health'){
        if(!healthCache || Date.now()-healthCache.time>30000)healthCache={time:Date.now(),pending:engine.health()};
        return json(res,200,{...await healthCache.pending,app:'linkdrop',mode:publicOrigin?'web':'local'});
      }
      if(req.method==='POST'&&url.pathname==='/api/inspect')return json(res,200,await engine.inspect(owner,(await body(req)).url));
      if(req.method==='GET'&&url.pathname==='/api/jobs')return json(res,200,{jobs:engine.list(owner)});
      if(req.method==='POST'&&url.pathname==='/api/jobs')return json(res,202,await engine.start(owner,await body(req)));
      const match=/^\/api\/jobs\/([a-f0-9-]{36})(?:\/(cancel|file))?$/.exec(url.pathname);
      if(match){
        if(req.method==='POST'&&match[2]==='cancel')return json(res,200,engine.cancel(owner,match[1]));
        if(req.method==='DELETE'&&!match[2]){await engine.remove(owner,match[1]);return json(res,200,{ok:true});}
        if(req.method==='GET'&&match[2]==='file'){
          const job=engine.get(owner,match[1]);
          if(job.state!=='complete')throw new AppError('This download is not ready yet.',409);
          const filename=(job.title.replace(/[<>:"/\\|?*\x00-\x1f\x7f]/g,'_').slice(0,100)||'video')+path.extname(job.file);
          res.writeHead(200,{'Content-Type':job.kind==='audio'?'audio/mpeg':'video/mp4','Content-Length':job.size,'Content-Disposition':`attachment; filename="download.${job.kind==='audio'?'mp3':'mp4'}"; filename*=UTF-8''${encodeURIComponent(filename).replace(/['()*]/g,c=>'%'+c.charCodeAt(0).toString(16))}`,'Cache-Control':'no-store'});
          const stream=createReadStream(job.file);stream.on('error',()=>res.destroy());res.on('close',()=>stream.destroy());stream.pipe(res);return;
        }
      }
      if(req.method==='GET'&&assets.has(url.pathname)){
        const [file,type]=assets.get(url.pathname);const data=await readFile(path.join(root,'public',file));res.writeHead(200,{'Content-Type':type,'Cache-Control':'no-cache'});res.end(data);return;
      }
      throw new AppError('Not found.',404);
    } catch(error) {
      if(!res.headersSent)json(res,error.status||500,{error:error.status?error.message:'Something went wrong. Please try again.'});else res.destroy();
      if(!error.status)console.error(error);
    }
  });
  server.requestTimeout=120000;server.headersTimeout=15000;
  return {server,engine,async close(){clearInterval(sessionTimer);await engine.close();server.closeIdleConnections();await new Promise(r=>server.close(r));}};
}

if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  const host=process.env.HOST || '127.0.0.1';const port=Number(process.env.PORT || 47821);
  if(!['127.0.0.1','localhost'].includes(host)&&!process.env.PUBLIC_ORIGIN)throw new Error('Set PUBLIC_ORIGIN before enabling network access.');
  const app=createApp();
  app.server.on('error',error=>{console.error(error.code==='EADDRINUSE'?`Port ${port} is already in use. Linkdrop may already be running.`:error.message);process.exit(1);});
  app.server.listen(port,host,()=>console.log(`Linkdrop is ready at ${process.env.PUBLIC_ORIGIN || `http://127.0.0.1:${port}`}\nNo ads. No subscriptions. Close this server to stop the app.`));
  for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>app.close().then(()=>process.exit(0)));
}
