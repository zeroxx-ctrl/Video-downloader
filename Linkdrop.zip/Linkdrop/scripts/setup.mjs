import { mkdir, readFile, writeFile, rename, copyFile, readdir, rm } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const bin=path.join(root,'runtime');
if (process.platform !== 'win32') { console.log('Install yt-dlp[default], FFmpeg and Node 22+ with your package manager, or use the supplied Dockerfile.'); process.exit(1); }
await mkdir(bin,{recursive:true});
async function get(url) {
  const r=await fetch(url,{signal:AbortSignal.timeout(300000),headers:{'User-Agent':'Linkdrop-Setup/1.0'}});
  if(!r.ok) throw new Error(`Download failed (${r.status}): ${url}`);
  return Buffer.from(await r.arrayBuffer());
}
async function checked(url, digest, destination) {
  console.log(`Downloading ${path.basename(destination)}...`);
  const data=await get(url);
  const hash=createHash('sha256').update(data).digest('hex');
  if(!/^[a-f0-9]{64}$/i.test(digest)||hash!==digest.toLowerCase()) throw new Error(`Checksum verification failed for ${path.basename(destination)}.`);
  await writeFile(`${destination}.part`,data);
  await rename(`${destination}.part`,destination);
}
try {
  if(!existsSync(path.join(bin,'yt-dlp.exe')) || process.argv.includes('--update')) {
    const release=JSON.parse((await get('https://api.github.com/repos/yt-dlp/yt-dlp/releases/latest')).toString());
    const asset=release.assets.find(a=>a.name==='yt-dlp.exe');
    let digest=asset.digest?.replace('sha256:','');
    if(!digest) digest=(await get(release.assets.find(a=>a.name==='SHA2-256SUMS').browser_download_url)).toString().split('\n').find(l=>/\syt-dlp.exe$/.test(l.trim()))?.split(/\s+/)[0];
    await checked(asset.browser_download_url,digest,path.join(bin,'yt-dlp.exe'));
  }
  if(!existsSync(path.join(bin,'ffmpeg.exe')) || !existsSync(path.join(bin,'ffprobe.exe'))) {
    const url='https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip';
    const digest=(await get(`${url}.sha256`)).toString().trim().split(/\s+/)[0];
    const archive=path.join(bin,'ffmpeg.zip');
    const cached=existsSync(archive)?createHash('sha256').update(await readFile(archive)).digest('hex'):null;
    if(cached!==digest.toLowerCase())await checked(url,digest,archive);
    const unpack=path.join(bin,'ffmpeg-unpack');
    const quote=s=>"'"+s.replaceAll("'","''")+"'";
    await rm(unpack,{recursive:true,force:true});
    execFileSync('powershell.exe',['-NoProfile','-Command',`[void][System.Reflection.Assembly]::LoadWithPartialName('System.IO.Compression.FileSystem'); [System.IO.Compression.ZipFile]::ExtractToDirectory(${quote(archive)}, ${quote(unpack)})`],{stdio:'inherit',windowsHide:true});
    const folder=(await readdir(unpack,{withFileTypes:true})).find(d=>d.isDirectory());
    if(!folder) throw new Error('FFmpeg archive did not contain a build folder.');
    const extracted=path.join(unpack,folder.name);
    for(const name of ['ffmpeg.exe','ffprobe.exe']) await copyFile(path.join(extracted,'bin',name),path.join(bin,name));
    if(existsSync(path.join(extracted,'LICENSE'))) await copyFile(path.join(extracted,'LICENSE'),path.join(bin,'FFmpeg-LICENSE.txt'));
    await rm(unpack,{recursive:true,force:true});
    await rm(archive);
  }
  console.log('Download engine ready.');
} catch(error) { console.error(`Setup could not finish: ${error.message}\nCheck your internet connection, then run Start-Linkdrop.cmd again.`);process.exitCode=1; }
