param([switch]$Stop, [switch]$Update, [switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
# Windows PowerShell may inherit PowerShell 7's module path from its parent.
$env:PSModulePath = "$PSHOME\Modules"
$appRoot = Split-Path -Parent $PSScriptRoot
$runtimeDir = Join-Path $appRoot 'runtime'
$pidPath = Join-Path $runtimeDir 'server.pid'
$appUrl = 'http://127.0.0.1:47821'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
try {
    if ($Stop) {
        if (!(Test-Path -LiteralPath $pidPath)) { Write-Host 'No Linkdrop process was started by this launcher.'; exit 0 }
        $serverPid = [int](Get-Content -LiteralPath $pidPath)
        $running = Get-CimInstance Win32_Process -Filter "ProcessId = $serverPid"
        $serverPath = Join-Path $appRoot 'server.mjs'
        if ($running -and $running.Name -eq 'node.exe' -and $running.CommandLine.Contains($serverPath)) {
            & taskkill.exe /PID $serverPid /T /F | Out-Null
            Write-Host 'Linkdrop stopped.'
        } else { Write-Host 'Linkdrop is already stopped.' }
        Remove-Item -LiteralPath $pidPath -Force
        exit 0
    }
    New-Item -ItemType Directory -Path $runtimeDir -Force | Out-Null
    $nodePath = Join-Path $runtimeDir 'node.exe'
    if (!(Test-Path -LiteralPath $nodePath)) {
        $installedNode = Get-Command node.exe -ErrorAction SilentlyContinue
        if ($installedNode -and [int]((& $installedNode.Source -p "process.versions.node.split('.')[0]")) -ge 22) {
            $nodePath = $installedNode.Source
        } else {
            Write-Host 'Downloading the free Node.js runtime (first run only)...'
            $releases = Invoke-RestMethod -Uri 'https://nodejs.org/dist/index.json'
            $version = ($releases | Where-Object { $_.version -match '^v24\.' -and $_.lts } | Select-Object -First 1).version
            if (!$version) { throw 'Could not find the Node.js 24 LTS release.' }
            $checksumText = (Invoke-WebRequest -UseBasicParsing -Uri "https://nodejs.org/dist/$version/SHASUMS256.txt").Content
            $line = ($checksumText -split "`n" | Where-Object { $_ -match '\swin-x64/node.exe\s*$' } | Select-Object -First 1)
            $expected = ($line.Trim() -split '\s+')[0]
            Invoke-WebRequest -UseBasicParsing -Uri "https://nodejs.org/dist/$version/win-x64/node.exe" -OutFile "$nodePath.part"
            if ((Get-FileHash -Algorithm SHA256 -LiteralPath "$nodePath.part").Hash.ToLower() -ne $expected.ToLower()) { throw 'Node.js checksum verification failed.' }
            Move-Item -LiteralPath "$nodePath.part" -Destination $nodePath -Force
            Invoke-WebRequest -UseBasicParsing -Uri "https://nodejs.org/dist/$version/LICENSE" -OutFile (Join-Path $runtimeDir 'Node-LICENSE.txt')
        }
    }
    if ($Update) {
        & $nodePath (Join-Path $PSScriptRoot 'setup.mjs') --update
        if ($LASTEXITCODE -ne 0) { throw 'Engine update failed. Stop Linkdrop and try again.' }
        Write-Host 'Engine updated. Restart Linkdrop to use the update.'
        exit 0
    }
    try {
        $status = Invoke-RestMethod -Uri "$appUrl/api/health" -TimeoutSec 3
        if ($status.app -eq 'linkdrop') { if (!$NoBrowser) { Start-Process $appUrl }; exit 0 }
    } catch { }
    & $nodePath (Join-Path $PSScriptRoot 'setup.mjs')
    if ($LASTEXITCODE -ne 0) { throw 'Setup failed. Check your internet connection and try again.' }
    $serverArgument = '"' + (Join-Path $appRoot 'server.mjs') + '"'
    $serverProcess = Start-Process -FilePath $nodePath -ArgumentList $serverArgument -WorkingDirectory $appRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $runtimeDir 'server.log') -RedirectStandardError (Join-Path $runtimeDir 'error.log')
    Set-Content -LiteralPath $pidPath -Value $serverProcess.Id
    for ($attempt=0; $attempt -lt 30; $attempt++) {
        try {
            $status = Invoke-RestMethod -Uri "$appUrl/api/health" -TimeoutSec 2
            if ($status.app -eq 'linkdrop') { if (!$NoBrowser) { Start-Process $appUrl }; Write-Host 'Linkdrop is running. Use Stop-Linkdrop.cmd when you are finished.'; exit 0 }
        } catch { }
        Start-Sleep -Milliseconds 500
    }
    throw 'Linkdrop did not start. See runtime\error.log for details.'
} catch { Write-Host "Could not start Linkdrop: $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
